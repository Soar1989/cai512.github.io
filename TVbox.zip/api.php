<?php

$id=rand(1,8);

$image[1]='http://111.67.193.163/TVbox//img/1.png';

$image[2]='http://111.67.193.163/TVbox//img/2.png';

$image[3]='http://111.67.193.163/TVbox//img/3.jpg';

$image[4]='http://111.67.193.163/TVbox//img/4.jpg';

$image[5]='http://111.67.193.163/TVbox//img/5.bmp';

$image[6]='http://111.67.193.163/TVbox//img/6.png';

$image[7]='http://111.67.193.163/TVbox//img/7.png';

$image[8]='http://111.67.193.163/TVbox//img/8.jpg';


header("location:$image[$id]");

?>